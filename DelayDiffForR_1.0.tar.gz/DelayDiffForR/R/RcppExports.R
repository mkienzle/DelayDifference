# A wrapper function
FitLW <- function(x,y,z){
.Call('FitLW',x,y,z)
}
