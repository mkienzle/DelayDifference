double WeeklyDD(const unsigned int time_index, const long unsigned int max_timestep, const std::vector<double> &TargetedEffort, const std::vector<double> &NontargetedEffort, const std::vector<double> &par);

